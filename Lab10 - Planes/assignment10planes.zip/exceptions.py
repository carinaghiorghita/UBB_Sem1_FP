class GameWonException(Exception):
    pass

class PlaneError(Exception):
    pass

class DirectionError(Exception):
    pass